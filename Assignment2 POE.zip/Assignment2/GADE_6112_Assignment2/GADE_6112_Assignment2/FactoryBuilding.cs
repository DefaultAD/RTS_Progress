﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    class FactoryBuilding : Building
    {
        private const int resources = 0;
        bool isSpawning = false;
        public Unit enemy;                
        public float spawnTime = 2f;           
        public Map[,] spawnPoints;

        public FactoryBuilding(int x, int y, int h, string t, string s)
            : base(x, y, h, t, s)
        {

        }

        
        public override bool isAlive()
        {
            if (this.buildingHealth <= 0)
                return false;
            else
                return true;

        }
        
        public override string toString()
        {
            string output = base.toString();

            output 
            = "Resource Type : " + RecourceType + Environment.NewLine
            + "Resource Per Game Tick : " + recourcePerGameTick + Environment.NewLine
            + "Recources Remaining : " + RecourceRemaining + Environment.NewLine
            + "Health : " + Health + Environment.NewLine
            + "Team : " + Team + Environment.NewLine
            + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
        public override string save()
        {
            
        }
    }
}
