﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    class ResourceBuilding : Building
    {
        public string resourceType = "Gold";
        public int recourcePerGameTick;
        public int recourceRemaining;

        public string RecourceType
        {
            get { return recourceType; }
            set { recourceType = value; }
        }

        public string RecourceRemaining
        {
            get { return recourceRemaining; }
            set { recourceRemaining = value; }
        }

        public int GenerateRecources()
        {
            if(recourceRemaining >= 0)
               recourceRemaining -= recourcePerGameTick;
        }
        
        public ResourceBuilding(int x, int y, int health, string team, string symbol)
           : base(x, y, health,team, symbol)
        {
           this.resourceType = resourceType;
           this.recourcePerGameTick = recourcePerGameTick;
           this.recourceRemaining = recourceRemaining;
        }
        
        
        public override bool isAlive()
        {            
            if (health > 0)
                return true;
            else
                return false;
        }         
        
        public override string toString()
        {
            string output = base.toString();

            output 
            = "Resource Type : " + RecourceType + Environment.NewLine
            + "Resource Per Game Tick : " + recourcePerGameTick + Environment.NewLine
            + "Recources Remaining : " + RecourceRemaining + Environment.NewLine
            + "Health : " + Health + Environment.NewLine
            + "Team : " + Team + Environment.NewLine
            + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }

        public override string save()
        {            
             FileStream outFile = new FileStream(@"File\ResourceBuilding.txt", FileMode.Append, FileAccess.Write);
             StreamWriter writer = new StreamWriter(outFile);
             writer.WriteLine(recourceType);
             writer.WriteLine(recourcePerGameTick);
             writer.WriteLine(recourceRemaining);
             writer.Close();
             outFile.Close();           
        }        
    }
}
