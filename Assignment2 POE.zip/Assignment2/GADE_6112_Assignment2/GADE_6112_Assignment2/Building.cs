﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    abstract class Building
    {
        protected int x;
        protected int y;
        protected int health;
        protected string team;
        protected bool type;
        protected string symbol;

        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public string Team
        {
            get { return team; }
            set { team = value; }
        }
        
        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        
        public Building(int x, int y, int health, string team, string symbol)
        {

            this.x = x;
            this.y = y;
            this.Health = health;
            this.Team = team;
            this.buildingName = symbol;
            //this.buildingName = name;

        }

        ~Building()
        {
        }

        public virtual bool isAlive() { return true; }
        
        public virtual string toString()
        {
            string output = "X : " + x + Environment.NewLine
            + "Y : " + y + Environment.NewLine
            + "Health : " + Health + Environment.NewLine
            + "Team : " + Team + Environment.NewLine
            + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
        public virtual string save() { }
    }
}


