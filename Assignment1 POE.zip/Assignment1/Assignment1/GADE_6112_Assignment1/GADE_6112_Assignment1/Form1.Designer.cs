﻿namespace GADE_6112_Assignment1
{
    partial class RTS_Simulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelMap = new System.Windows.Forms.Label();
            this.labelStats = new System.Windows.Forms.Label();
            this.timerTicks = new System.Windows.Forms.Timer(this.components);
            this.labelGameTime = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelMap
            // 
            this.labelMap.AutoSize = true;
            this.labelMap.Location = new System.Drawing.Point(30, 29);
            this.labelMap.MaximumSize = new System.Drawing.Size(100, 100);
            this.labelMap.Name = "labelMap";
            this.labelMap.Size = new System.Drawing.Size(93, 32);
            this.labelMap.TabIndex = 0;
            this.labelMap.Text = "label1";
            this.labelMap.Click += new System.EventHandler(this.labelMap_Click);
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Location = new System.Drawing.Point(883, 600);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(93, 32);
            this.labelStats.TabIndex = 1;
            this.labelStats.Text = "label1";
            // 
            // labelGameTime
            // 
            this.labelGameTime.AutoSize = true;
            this.labelGameTime.Location = new System.Drawing.Point(686, 28);
            this.labelGameTime.Name = "labelGameTime";
            this.labelGameTime.Size = new System.Drawing.Size(93, 32);
            this.labelGameTime.TabIndex = 2;
            this.labelGameTime.Text = "label1";
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(889, 29);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(201, 169);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(889, 234);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(201, 174);
            this.buttonExit.TabIndex = 4;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // RTS_Simulator
            // 
            this.ClientSize = new System.Drawing.Size(1144, 868);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.labelGameTime);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.labelMap);
            this.Name = "RTS_Simulator";
            this.Load += new System.EventHandler(this.RTS_Simulator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Label labelMap;
        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.Timer timerTicks;
        private System.Windows.Forms.Label labelGameTime;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonExit;
    }
}

